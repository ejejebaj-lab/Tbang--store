import os, asyncio
from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, WebAppInfo
from aiogram.filters import CommandStart
from dotenv import load_dotenv
load_dotenv()
TOKEN=os.getenv("BOT_TOKEN","")
APP_URL=os.getenv("PUBLIC_URL","")
if not TOKEN: raise RuntimeError("Thiếu BOT_TOKEN trong .env")
if not APP_URL.startswith("https://"): raise RuntimeError("PUBLIC_URL phải là HTTPS")
bot=Bot(TOKEN); dp=Dispatcher()
kb=ReplyKeyboardMarkup(keyboard=[
 [KeyboardButton(text="🛒 MỞ SOP TB STORE",web_app=WebAppInfo(url=APP_URL))],
 [KeyboardButton(text="🆘 HỖ TRỢ"),KeyboardButton(text="📢 THÔNG TIN ADMIN")]
],resize_keyboard=True)
@dp.message(CommandStart())
async def start(m:Message):
    await m.answer("CHÀO MỪNG BẠN ĐẾN VỚI SOP TB STORE\\n\\nChọn MỞ SOP TB STORE để mua hàng, nạp tiền và xem lịch sử.",reply_markup=kb)
@dp.message(F.text=="🆘 HỖ TRỢ")
async def support(m:Message):
    await m.answer("📞 THÔNG TIN HỖ TRỢ SOP TB STORE\nAdmin: @tranbang0346\nZalo: 0346398015")
@dp.message(F.text=="📢 THÔNG TIN ADMIN")
async def admin_info(m:Message):
    await m.answer("📢 THÔNG BÁO / LIÊN HỆ ADMIN\nAdmin: @tranbang0346\nZalo: 0346398015")
async def main(): await dp.start_polling(bot)
if __name__=="__main__": asyncio.run(main())
