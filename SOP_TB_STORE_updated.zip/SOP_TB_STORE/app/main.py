import os, hmac, hashlib, json, sqlite3, time, secrets
from urllib.parse import parse_qsl
from contextlib import contextmanager
from fastapi import FastAPI, Header, HTTPException, Request, Depends
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

DB = os.getenv("DATABASE_PATH", "qhuy.sqlite3")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_IDS = {x.strip() for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()}
ADMIN_KEY = os.getenv("ADMIN_KEY", "CHANGE_ME_ADMIN_KEY")
PAYMENT_WEBHOOK_KEY = os.getenv("PAYMENT_WEBHOOK_KEY", "CHANGE_ME_WEBHOOK_KEY")
BANK_ID = os.getenv("BANK_ID", "")
BANK_ACCOUNT = os.getenv("BANK_ACCOUNT", "")
BANK_NAME = os.getenv("BANK_NAME", "SOP TB STORE")
PUBLIC_URL = os.getenv("PUBLIC_URL", "https://your-domain.example")
CURRENCY = "VND"

app = FastAPI(title="SOP TB STORE API", version="1.0.0")
app.mount("/static", StaticFiles(directory="app/static"), name="static")

@contextmanager
def db():
    con = sqlite3.connect(DB, timeout=20)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, tg_id TEXT UNIQUE, username TEXT, balance INTEGER NOT NULL DEFAULT 0, created_at INTEGER);
        CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, code TEXT UNIQUE, category TEXT, name TEXT, price INTEGER, stock INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, delivery_text TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, tg_id TEXT, product_code TEXT, quantity INTEGER, total INTEGER, status TEXT, delivery TEXT, created_at INTEGER);
        CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY, tg_id TEXT, kind TEXT, amount INTEGER, ref TEXT UNIQUE, note TEXT, created_at INTEGER);
        CREATE TABLE IF NOT EXISTS api_tokens(id INTEGER PRIMARY KEY, tg_id TEXT, token_hash TEXT UNIQUE, label TEXT, created_at INTEGER);
        """)
        c.execute("INSERT OR IGNORE INTO products(code,category,name,price,stock,delivery_text) VALUES(?,?,?,?,?,?)",
                  ("DEMO-KEY-1D","MIZZE CHEAT","Demo KEY 1 ngày",20000,100,"KEY-DEMO-REPLACE-ME"))
init_db()

def verify_telegram_init_data(init_data: str):
    if not BOT_TOKEN: raise HTTPException(503, "Bot chưa cấu hình BOT_TOKEN")
    vals = dict(parse_qsl(init_data, keep_blank_values=True))
    their_hash = vals.pop("hash", None)
    if not their_hash: raise HTTPException(401, "Thiếu Telegram initData")
    data_check = "\\n".join(f"{k}={v}" for k,v in sorted(vals.items()))
    secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, data_check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, their_hash): raise HTTPException(401, "initData không hợp lệ")
    if int(time.time()) - int(vals.get("auth_date", "0")) > 86400: raise HTTPException(401, "initData hết hạn")
    user = json.loads(vals.get("user", "{}"))
    if not user.get("id"): raise HTTPException(401, "Không đọc được Telegram user")
    return str(user["id"]), user.get("username","")

def user_from_init(x_telegram_init_data: str = Header(default="")):
    return verify_telegram_init_data(x_telegram_init_data)

def ensure_user(tg_id, username=""):
    with db() as c:
        c.execute("INSERT OR IGNORE INTO users(tg_id,username,created_at) VALUES(?,?,?)",(tg_id,username,int(time.time())))
        if username: c.execute("UPDATE users SET username=? WHERE tg_id=?",(username,tg_id))

def require_admin(x_admin_key: str = Header(default="")):
    if not hmac.compare_digest(x_admin_key, ADMIN_KEY): raise HTTPException(403, "Admin key không đúng")
    return True

class BuyBody(BaseModel):
    product_code: str
    quantity: int = Field(ge=1, le=100)
    request_id: str = Field(min_length=8, max_length=100)

class TopupBody(BaseModel):
    amount: int = Field(ge=10000, le=100000000)

@app.get("/", response_class=HTMLResponse)
def home():
    return FileResponse("app/static/index.html")

@app.get("/health")
def health(): return {"ok": True, "service":"SOP TB STORE"}

@app.get("/api/me")
def me(user=Depends(user_from_init)):
    tg_id, username = user; ensure_user(tg_id, username)
    with db() as c:
        row = c.execute("SELECT tg_id,username,balance FROM users WHERE tg_id=?",(tg_id,)).fetchone()
    return dict(row)

@app.get("/api/products")
def products():
    with db() as c:
        rows = c.execute("SELECT code,category,name,price,stock FROM products WHERE active=1 ORDER BY category,name").fetchall()
    return [dict(r) for r in rows]

@app.post("/api/buy")
def buy(body: BuyBody, user=Depends(user_from_init)):
    tg_id, username = user; ensure_user(tg_id, username)
    with db() as c:
        previous = c.execute("SELECT * FROM orders WHERE id=?",(int(hashlib.sha256(body.request_id.encode()).hexdigest()[:12],16),)).fetchone()
        if previous: return {"ok":True,"replayed":True,"order":dict(previous)}
        p = c.execute("SELECT * FROM products WHERE code=? AND active=1",(body.product_code,)).fetchone()
        if not p: raise HTTPException(404,"Không tìm thấy sản phẩm")
        if p["stock"] < body.quantity: raise HTTPException(409,"Không đủ hàng")
        total = p["price"] * body.quantity
        u = c.execute("SELECT balance FROM users WHERE tg_id=?",(tg_id,)).fetchone()
        if not u or u["balance"] < total: raise HTTPException(402,"Số dư không đủ")
        # Unique request reference prevents duplicate charges.
        ref = "buy:"+tg_id+":"+body.request_id
        if c.execute("SELECT 1 FROM ledger WHERE ref=?",(ref,)).fetchone():
            raise HTTPException(409,"request_id đã được sử dụng")
        c.execute("UPDATE users SET balance=balance-? WHERE tg_id=?",(total,tg_id))
        c.execute("UPDATE products SET stock=stock-? WHERE code=?",(body.quantity,body.product_code))
        delivery = (p["delivery_text"] or "Đơn hàng đã được tiếp nhận. Admin sẽ giao hàng.") 
        order_id = int(hashlib.sha256(body.request_id.encode()).hexdigest()[:12],16)
        c.execute("INSERT INTO orders(id,tg_id,product_code,quantity,total,status,delivery,created_at) VALUES(?,?,?,?,?,?,?,?)",
                  (order_id,tg_id,p["code"],body.quantity,total,"paid",delivery,int(time.time())))
        c.execute("INSERT INTO ledger(tg_id,kind,amount,ref,note,created_at) VALUES(?,?,?,?,?,?)",
                  (tg_id,"purchase",-total,ref,p["name"],int(time.time())))
    return {"ok":True,"order_id":order_id,"total_vnd":total,"delivery":delivery}

@app.post("/api/topup/create")
def topup_create(body: TopupBody, user=Depends(user_from_init)):
    tg_id, username = user; ensure_user(tg_id, username)
    ref = "QH"+str(int(time.time()))+secrets.token_hex(3).upper()
    with db() as c:
        c.execute("INSERT INTO ledger(tg_id,kind,amount,ref,note,created_at) VALUES(?,?,?,?,?,?)",
                  (tg_id,"topup_pending",body.amount,ref,"Chờ thanh toán VietQR",int(time.time())))
    qr = ""
    if BANK_ID and BANK_ACCOUNT:
        from urllib.parse import quote
        qr = f"https://img.vietqr.io/image/{quote(BANK_ID)}-{quote(BANK_ACCOUNT)}-compact2.png?amount={body.amount}&addInfo={quote(ref)}&accountName={quote(BANK_NAME)}"
    return {"reference":ref,"amount":body.amount,"bank_id":BANK_ID,"account":BANK_ACCOUNT,"account_name":BANK_NAME,"qr_url":qr,
            "note":"Chỉ được cộng tiền sau khi webhook từ nhà cung cấp thanh toán xác nhận giao dịch."}

@app.post("/webhook/vietqr")
async def vietqr_webhook(request: Request, x_api_key: str = Header(default="")):
    if not hmac.compare_digest(x_api_key, PAYMENT_WEBHOOK_KEY): raise HTTPException(401,"Webhook key không hợp lệ")
    data = await request.json()
    # Adapt these fields to the bank/payment provider's signed webhook schema.
    ref = str(data.get("content") or data.get("description") or data.get("transferContent") or "")
    txid = str(data.get("id") or data.get("transactionId") or "")
    amount = int(data.get("transferAmount") or data.get("amount") or 0)
    if not ref or not txid or amount <= 0: raise HTTPException(400,"Thiếu mã giao dịch/nội dung/số tiền")
    with db() as c:
        pending = c.execute("SELECT * FROM ledger WHERE ref=? AND kind='topup_pending'",(ref.strip(),)).fetchone()
        if not pending: return {"ok":True,"ignored":"Không tìm thấy mã nạp"}
        if amount < pending["amount"]: raise HTTPException(400,"Số tiền chuyển thấp hơn yêu cầu")
        credit_ref = "bank:"+txid
        if c.execute("SELECT 1 FROM ledger WHERE ref=?",(credit_ref,)).fetchone(): return {"ok":True,"duplicate":True}
        c.execute("UPDATE users SET balance=balance+? WHERE tg_id=?",(pending["amount"],pending["tg_id"]))
        c.execute("UPDATE ledger SET kind='topup_paid',note=? WHERE ref=?",(f"Đã nhận giao dịch {txid}",ref.strip()))
        c.execute("INSERT INTO ledger(tg_id,kind,amount,ref,note,created_at) VALUES(?,?,?,?,?,?)",
                  (pending["tg_id"],"topup",pending["amount"],credit_ref,ref.strip(),int(time.time())))
    return {"ok":True,"credited":pending["amount"]}

@app.get("/api/history")
def history(user=Depends(user_from_init)):
    tg_id,_ = user
    with db() as c:
        rows = c.execute("SELECT kind,amount,ref,note,created_at FROM ledger WHERE tg_id=? ORDER BY id DESC LIMIT 100",(tg_id,)).fetchall()
    return [dict(r) for r in rows]

@app.get("/api/admin/products")
def admin_products(_: bool=Depends(require_admin)):
    with db() as c: return [dict(r) for r in c.execute("SELECT * FROM products ORDER BY id DESC").fetchall()]

class ProductBody(BaseModel):
    code:str; category:str; name:str; price:int=Field(ge=0); stock:int=Field(ge=0); delivery_text:str=""

@app.post("/api/admin/products")
def add_product(body: ProductBody, _: bool=Depends(require_admin)):
    with db() as c:
        try: c.execute("INSERT INTO products(code,category,name,price,stock,delivery_text) VALUES(?,?,?,?,?,?)",
                       (body.code,body.category,body.name,body.price,body.stock,body.delivery_text))
        except sqlite3.IntegrityError: raise HTTPException(409,"Mã sản phẩm đã tồn tại")
    return {"ok":True}

@app.post("/api/admin/credit/{tg_id}")
def admin_credit(tg_id:str, amount:int, _:bool=Depends(require_admin)):
    if amount == 0: raise HTTPException(400,"Số tiền không hợp lệ")
    ref="admin:"+secrets.token_hex(12)
    with db() as c:
        c.execute("INSERT OR IGNORE INTO users(tg_id,created_at) VALUES(?,?)",(tg_id,int(time.time())))
        c.execute("UPDATE users SET balance=balance+? WHERE tg_id=?",(amount,tg_id))
        c.execute("INSERT INTO ledger(tg_id,kind,amount,ref,note,created_at) VALUES(?,?,?,?,?,?)",
                  (tg_id,"admin_adjust",amount,ref,"Điều chỉnh bởi admin",int(time.time())))
    return {"ok":True}

@app.get("/api/admin/summary")
def admin_summary(_:bool=Depends(require_admin)):
    with db() as c:
        users=c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        orders=c.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"]
        revenue=c.execute("SELECT COALESCE(SUM(total),0) n FROM orders WHERE status='paid'").fetchone()["n"]
    return {"users":users,"orders":orders,"revenue_vnd":revenue}
