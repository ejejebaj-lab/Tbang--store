# SOP TB STORE — Telegram Bot + Mini App + API (starter)

Bộ mã nguồn MVP có:
- Telegram Bot mở Mini App bằng WebApp button.
- Mini App: danh sách sản phẩm, mua bằng số dư, tạo yêu cầu nạp VietQR, lịch sử, hồ sơ.
- Backend FastAPI + SQLite: tài khoản Telegram, tồn kho, đơn hàng, ledger, API webhook nạp tiền.
- Admin API cơ bản: thêm sản phẩm, cộng/trừ số dư, xem thống kê.

## 1. Cần chuẩn bị
1. Tạo bot qua `@BotFather`, lấy Bot Token.
2. Có tên miền và VPS; Mini App bắt buộc chạy qua HTTPS.
3. Chọn ngân hàng và đơn vị nhận webhook giao dịch (ví dụ nhà cung cấp hỗ trợ webhook). VietQR chỉ tạo mã QR; bản thân ảnh QR không xác nhận tiền vào.
4. Thông tin ngân hàng của chính bạn và quy định xử lý thanh toán.

## 2. Cài đặt
```bash
cp .env.example .env
# sửa .env, không đưa .env lên Git hoặc gửi công khai
docker compose up -d --build
```
Mở `https://TEN-MIEN/health` để kiểm tra API sau khi cấu hình reverse proxy HTTPS (Nginx/Caddy).
Đặt `PUBLIC_URL=https://TEN-MIEN`, khởi động lại container rồi mở bot và gửi `/start`.

## 3. Cấu hình Telegram
- Trong BotFather, cấu hình domain Mini App bằng tên miền của bạn.
- Chỉ mở Mini App qua bot Telegram để có `Telegram.WebApp.initData`.
- Backend xác minh chữ ký `initData`, không tin `user_id` do client tự gửi.

## 4. Nạp tiền VietQR
- Thông tin TPBank đã được điền trong file `.env`: BANK_ID=VCB, BANK_ACCOUNT=9964447934, BANK_NAME=TRAN QUANG HUY. Hãy xác nhận tên chủ tài khoản đúng chính tả như ngân hàng đăng ký trước khi nhận tiền thật.
- Endpoint `POST /api/topup/create` tạo mã tham chiếu và QR.
- Cấu hình đơn vị thanh toán/ngân hàng gửi webhook `POST https://TEN-MIEN/webhook/vietqr`.
- Header cần có `X-Api-Key: <PAYMENT_WEBHOOK_KEY>`.
- JSON webhook cần ánh xạ `content` (nội dung chuyển khoản), `id` (mã giao dịch duy nhất), `transferAmount` (số tiền). Nếu nhà cung cấp dùng schema khác, phải sửa adapter `vietqr_webhook`.
- Chạy thử bằng giao dịch nhỏ; xác nhận chữ ký webhook theo tài liệu chính thức của nhà cung cấp trước khi dùng tiền thật.

**Quan trọng:** API webhook mẫu đang dùng shared API key để minh họa. Trước production, phải thay bằng xác minh chữ ký/HMAC hoặc IP allowlist theo tài liệu nhà cung cấp; không mở endpoint cộng tiền công khai. Chỉ cộng tiền khi giao dịch đã được xác minh từ nguồn đáng tin cậy.

## 5. Admin API
Dùng header `X-Admin-Key: <ADMIN_KEY>`.
- `GET /api/admin/summary`
- `GET /api/admin/products`
- `POST /api/admin/products` JSON: `{"code":"KEY-1D","category":"MIZZE CHEAT","name":"KEY 1 ngày","price":20000,"stock":20,"delivery_text":"KEY mẫu"}`
- `POST /api/admin/credit/{telegram_id}?amount=50000` (amount âm để trừ tiền)

Đây là API quản trị tối thiểu, chưa có giao diện Admin web, phân quyền nhiều cấp hay audit log chi tiết.

## 6. API khách hàng
Các endpoint `/api/me`, `/api/buy`, `/api/history`, `/api/topup/create` yêu cầu header `X-Telegram-Init-Data` chứa nguyên `Telegram.WebApp.initData`.
- `GET /api/products` công khai.
- `POST /api/buy`: `{"product_code":"DEMO-KEY-1D","quantity":1,"request_id":"unique-request-123"}`.
- `POST /api/topup/create`: `{"amount":50000}`.

## 7. Trước khi chạy thật
- Thay sản phẩm demo, key demo và nội dung hỗ trợ.
- Không lưu key thật dạng plaintext; bổ sung mã hóa kho key và cơ chế giao key an toàn.
- Dùng PostgreSQL thay SQLite khi có nhiều người dùng.
- Bổ sung rate limit, backup, log, HTTPS, CSRF/CORS policy, monitoring, quyền admin, xác minh webhook chữ ký, xử lý idempotency theo chuẩn nhà cung cấp.
- Không dùng thông tin tài khoản ngân hàng hoặc token giả; mọi biến `.env` phải do chủ shop tự điền.


## Cảnh báo triển khai
Bản này chỉ là starter để kiểm tra cấu trúc. Endpoint webhook mẫu `/webhook/vietqr` hiện dùng API key minh họa, chưa xác minh chữ ký HMAC-SHA256 chuẩn SePay; không cấu hình webhook nhận tiền thật và không nạp tiền thật cho đến khi thay adapter bằng xác minh `X-SePay-Signature`/`X-SePay-Timestamp`, kiểm tra tài khoản nhận, mã thanh toán, số tiền, chống replay và idempotency. Bot polling (`bot.py`) cần chạy thành Background Worker riêng; web service chỉ chạy FastAPI. Cần persistent disk/PostgreSQL để dữ liệu không mất khi redeploy.


## Render Free: API + Telegram bot in one Web Service

This starter includes `start.py`, which starts Uvicorn and (when `BOT_TOKEN` is set)
the Telegram polling bot in the same container. Deploy the repository as a Docker
**Web Service**. Do not create a separate Background Worker for this arrangement.

Set `BOT_TOKEN`, `PUBLIC_URL`, `ADMIN_IDS`, and the other required environment
variables in Render's Environment page. Never commit `.env` or real secrets.

Important limitations:
- Render Free web services can spin down after inactivity. When the service sleeps,
  the Telegram polling bot also stops responding. This is suitable for testing only,
  not dependable 24/7 shop operation.
- The SQLite file on a free service's filesystem is ephemeral and can be lost on
  redeploy/restart. Do not store real customer balances/orders until persistent
  storage or a managed database is configured.
- The sample `/webhook/vietqr` endpoint is NOT a production SePay webhook integration.
  It uses a simple API key and does not validate SePay's HMAC signature. Do not
  connect it to live customer payments until proper SePay signature verification,
  receiving-account/amount checks, and idempotency protections are implemented.
