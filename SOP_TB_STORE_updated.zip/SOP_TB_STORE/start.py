"""Run the FastAPI web server and Telegram polling bot in one Render Web Service.

This is a low-cost/testing arrangement, not a 24/7 guarantee on Render Free:
free web services can sleep after inactivity, which stops bot polling too.
"""
import os
import signal
import subprocess
import sys
import time

processes = []
stopping = False

def stop_all(*_):
    global stopping
    stopping = True
    for proc in processes:
        if proc.poll() is None:
            proc.terminate()

signal.signal(signal.SIGTERM, stop_all)
signal.signal(signal.SIGINT, stop_all)

# Start the HTTP API.
api = subprocess.Popen([
    sys.executable, "-m", "uvicorn", "app.main:app",
    "--host", "0.0.0.0", "--port", os.getenv("PORT", "8000")
])
processes.append(api)

# Start Telegram long-polling only when a token has been configured.
if os.getenv("BOT_TOKEN", "").strip():
    bot = subprocess.Popen([sys.executable, "bot.py"])
    processes.append(bot)
    print("Telegram bot process started.", flush=True)
else:
    print("BOT_TOKEN is empty; API is running without the Telegram bot.", flush=True)

try:
    while not stopping:
        for proc in processes:
            code = proc.poll()
            if code is not None:
                print(f"Child process {proc.args} exited with code {code}.", flush=True)
                stop_all()
                break
        time.sleep(2)
finally:
    for proc in processes:
        if proc.poll() is None:
            proc.terminate()
    deadline = time.time() + 15
    for proc in processes:
        if proc.poll() is None:
            try:
                proc.wait(timeout=max(1, deadline - time.time()))
            except subprocess.TimeoutExpired:
                proc.kill()
